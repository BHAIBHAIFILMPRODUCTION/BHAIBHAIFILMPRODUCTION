
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Instagram, Youtube, MessageCircle } from "lucide-react";

export default function HomePage() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      <header className="text-center py-10 bg-gradient-to-b from-zinc-900 to-black">
        <h1 className="text-5xl font-bold mb-2">BHAI BHAI FILM PRODUCTION</h1>
        <p className="text-lg text-gray-400">Lights. Camera. Action.</p>
      </header>
      <section className="p-8 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">About Us</h2>
        <p className="text-gray-300">
          Bhai Bhai Film Production is a creative house specializing in cinematic storytelling,
          music videos, reels, short films and commercial content. Based in India, we bring dreams
          to the screen.
        </p>
      </section>
      <section className="bg-zinc-800 p-8">
        <h2 className="text-3xl font-semibold mb-4 text-center">Our Work</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card><CardContent className="p-4">🎬 Music Video 1</CardContent></Card>
          <Card><CardContent className="p-4">🎥 Short Film 1</CardContent></Card>
          <Card><CardContent className="p-4">📸 Behind The Scenes</CardContent></Card>
        </div>
      </section>
      <section className="p-8 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">🎬 Upcoming Project</h2>
        <div className="aspect-w-16 aspect-h-9">
          <iframe
            src="https://www.instagram.com/reel/DMnz4nUspbR/embed"
            width="100%"
            height="500"
            allowTransparency="true"
            frameBorder="0"
            scrolling="no"
            allowFullScreen
            className="w-full rounded-xl"
          ></iframe>
        </div>
      </section>
      <section className="p-8 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">Our Services</h2>
        <ul className="list-disc pl-5 text-gray-300">
          <li>Video Production & Direction</li>
          <li>Editing & VFX</li>
          <li>Event Shoots & Music Videos</li>
          <li>Social Media Reels & Content</li>
        </ul>
      </section>
      <section className="bg-zinc-900 p-8 text-center">
        <h2 className="text-3xl font-semibold mb-4">Get in Touch</h2>
        <div className="flex justify-center gap-6 mb-4">
          <a href="mailto:contact@bhaibhaifilm.com" className="hover:text-red-400"><Mail /></a>
          <a href="tel:+918109734246" className="hover:text-red-400"><Phone /></a>
          <a href="https://www.instagram.com/bhaibhaifilmproduction" className="hover:text-red-400"><Instagram /></a>
          <a href="https://youtube.com/@bhaibhaifilmproduction-1?si=o4ZzYkcrMO4lPrdC" className="hover:text-red-400"><Youtube /></a>
        </div>
        <Button className="bg-red-600 hover:bg-red-700 text-white">Send Inquiry</Button>
      </section>
      <a
        href="https://wa.me/918109734246"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-50"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
      </a>
      <footer className="text-center text-gray-500 p-4 text-sm">
        © 2025 Bhai Bhai Film Production. All rights reserved.
      </footer>
    </div>
  );
}
